# 展序·厦大 Web 首页（Vue）

课程作业页面复刻自 Figma 原型中的 **W01 / 首页**，仅包含 Web 首页。

原型文件：[展序·厦大｜Figma](https://www.figma.com/design/jfLt6B1elspRvgGAt3ff7P)，页面节点 `W01 / 首页`（`5:2`）。

## 运行

请用 Vite 启动页面，不要直接双击根目录的 `index.html`。直接打开时会显示启动提示，因为 Vue 单文件组件需要经过 Vite 编译。

```bash
npm install
npm run dev
```

Vite 会在终端显示本地访问地址。打包可运行 `npm run build`，输出位于 `dist/`。

## 提交材料

- `提交材料/01-原型页面截图.png`：Figma 中 W01 首页截图（1440 × 1024）。
- `提交材料/02-Vue开发界面截图.png`：本地 Vue 页面运行截图。

本项目使用 Vue 3 和 Vite；图片素材保存在 `public/assets/`。
