# 展序·厦大：展览管理与浏览模块

本次作业实现同一模块的三端全栈闭环：**管理员创建与编辑展览 → 保存到 MySQL → 公开后在 Web 和移动端展示 → 下架后从公开列表与详情中隐藏。**

技术路线沿用已有工程：Spring Boot + MySQL + Vue 3。移动端采用独立 Vue 移动 H5 工程，可在手机浏览器访问；不含 Android/iOS 原生安装包或微信小程序。

## 1. 产品与原型

**展序·厦大**面向校园艺术展览与青年创作，帮助策展人员发布展览，也帮助观众发现、浏览和回看校园展览。产品整体原型还包含作品征集、审核、预约与核验；本次只开发其中的“展览管理与浏览”模块。

- 原型链接：[展序·厦大 · Figma](https://www.figma.com/design/jfLt6B1elspRvgGAt3ff7P)。链接来自已有项目记录；查看权限由原型文件所有者控制。
- 原型对应：Web 的 W01 首页、W02 展览列表、W03 展览详情；后台的 A02 展览管理、A03 编辑展览；移动端的 M02 发现展览、M03 展览详情。
- 本次根据作业范围做了调整：列表合并到 Web 首页；管理端增加真实登录与数据库保存；移动端集中展示发现与详情。移除未实现流程的入口，避免把静态按钮当作完成的功能。
- 视觉延续米白纸感背景、湖蓝文字、砖红操作按钮和校园插画。所有素材随工程打包，不依赖在线字体服务。

展览名称、作品、作者及日期均为课程虚构演示数据，不代表厦门大学的真实展览安排。

## 2. 功能与设计思路

| 端 | 已实现功能 | 数据来源 |
| --- | --- | --- |
| 管理后台 | 登录/退出、会话恢复、展览统计、名称搜索、状态筛选、新建与编辑、选择封面、公开/下架、删除未公开草稿 | Spring Boot 管理接口与 MySQL |
| Web | 展览列表、名称搜索、状态筛选、展览详情、刷新后恢复详情、精选作品展示、加载/空列表/错误/重试状态 | 公开接口与 MySQL；图片为本地素材 |
| 移动 H5 | 独立移动布局、发现展览、名称搜索、状态筛选、详情、底部导航、手动刷新、错误重试 | 与 Web 相同的公开接口 |

**设计原则：**三个前端独立构建，后端共用，避免各端保存互相矛盾的展览数据。列表和详情使用同一条公开规则；后台保存后，观众刷新页面或重新查询即可看到变化，不使用 WebSocket 实时推送。

```text
管理后台 Vue :5174 ── 管理会话 + CRUD ─┐
Web Vue      :5173 ── 公开查询 ────────┼─ Spring Boot :8081 ─ MySQL
移动 H5 Vue  :5175 ── 公开查询 ────────┘
```

三端 Vite 将同源 `/api` 请求转发给后端。数据库账号只允许读取数据库和增删改 `exhibitions` 表，不拥有建表、删表权限。管理员身份通过后端环境变量配置；登录后使用服务端会话和 HttpOnly、SameSite=Strict Cookie，30 分钟无活动后过期。写入请求必须携带自定义安全请求头，服务端不开放跨域 CORS。

### 业务规则

1. 标题、简介、地点、封面和开始/结束时间必填；结束时间必须晚于开始时间。后端独立校验，不仅依赖浏览器校验。
2. 业务阶段可选草稿、征集中、筹备中、展出中、已归档、已取消；本次由管理员选择，不按系统时钟自动变化，也不强制逐阶段流转。
3. 只有“征集中、展出中、已归档”允许公开；公开接口同时要求 `public_visible=1`。未公开展览即使知道 ID，详情也返回 404。
4. 下架保留全部记录；物理删除只允许未公开草稿，存在外键关联时返回 409，不级联删除作品或投稿。界面提供删除/下架确认。
5. 封面只允许四张随包素材，避免任意 URL；策展文字用 Vue 文本插值展示，不执行 HTML。管理接口和错误信息不返回数据库密码、SQL 或用户联系方式。

## 3. 提交包结构

```text
全栈作业提交-2026-10-28/
├── readme.md                     产品、原型、设计、接口与启动说明
├── screenshots/                  三端实际运行截图，共 7 张
│   ├── 01-管理后台-登录.png
│   ├── 02-管理后台-展览管理.png
│   ├── 03-管理后台-编辑展览.png
│   ├── 04-Web-展览首页.png
│   ├── 05-Web-展览详情.png
│   ├── 06-移动端-发现展览.png
│   └── 07-移动端-展览详情.png
├── database/
│   ├── schema.sql                MySQL 建库、19 张原有设计表及约束
│   ├── seed.sql                  初始演示展览、作品、策展内容
│   └── create-user.example.sql   应用数据库账号与最小写入权限示例
├── backend/                      Spring Boot 后端工程
│   ├── pom.xml                   Maven 依赖与构建配置
│   ├── .env.example              连接信息与管理账号配置模板
│   └── src/                      Java 接口、查询、校验、鉴权、集成测试
├── admin/                        管理后台 Vue 工程
├── web/                          Web Vue 工程
├── mobile/                       移动 H5 Vue 工程
├── tests/                        浏览器验收脚本、测试结果与验收说明
└── SHA256SUMS.txt                包内文件校验清单
```

每个前端均含 `src/`、`public/assets/`、`package.json`、`package-lock.json`、`vite.config.js`、`index.html`，可独立安装依赖与启动。ZIP 不包含 `node_modules`、编译产物、私人 `.env.local`、数据库数据目录及 macOS 资源叉文件。

后端主要文件：`ExhibitionController` 管理路由；`ExhibitionRepository` 执行参数化 SQL 与事务；`AdminAccess` 校验会话和写入请求；`AdminSessionController` 处理登录退出；`ApiErrors` 统一业务异常；`HomeController/Repository/Response` 复用原首页展览与精选作品查询。

数据库沿用原产品 19 表结构以保留原设计关系，实际写入模块为 `exhibitions`，`users` 提供创建人外键。Web 首页精选作品还关联展区、投稿版本和文件表。初始数据为 5 个展览（3 公开、1 私有、1 草稿）及 4 件可公开展示作品，另有隐藏作品用于隔离测试。未实现业务对应的表只保留结构。

## 4. 环境要求

| 工具 | 要求 / 本次实测 |
| --- | --- |
| Java | JDK 21；实测 21.0.12.1 |
| Maven | 3.6.3 或以上；使用 `pom.xml` 下载依赖 |
| MySQL | 8.0.16 或以上；实测 8.4.11，需支持 CHECK 约束 |
| Node.js / npm | Node.js 22.12 或以上；实测 Node 26.7.0，使用 npm 锁文件安装 |
| 浏览器 | 当前版本 Chrome/Edge；实测 Chrome 桌面与 390×844 移动视口 |

已锁定安装的前端版本为 Vue 3.5.44、Vite 7.3.7；后端为 Spring Boot 3.5.16。首次安装依赖需要网络。运行后不依赖学校认证、第三方云数据库或远程图片服务。

## 5. 项目启动

### 第一步：导入数据库

启动 MySQL，在**解压后的根目录**打开终端。下列命令按常见端口 3306 编写；本机演示实例使用 3307，使用其他端口时同步修改命令和 `DB_URL`。

```bash
mysql --protocol=TCP -h127.0.0.1 -P3306 -uroot -p < database/schema.sql
mysql --protocol=TCP -h127.0.0.1 -P3306 -uroot -p < database/seed.sql
```

脚本建立独立数据库 `zhanxu_fullstack`，不会改动旧作业的 `zhanxu_xmu`。仅在新的空数据库中导入一次；没有 DROP/TRUNCATE，重复导入会因已有表/主键报错。Windows PowerShell 可使用 `cmd /c "mysql --protocol=TCP -h127.0.0.1 -P3306 -uroot -p < database\schema.sql"`，再对 `seed.sql` 执行相同方式导入；也可以用 MySQL Workbench 的 SQL 编辑器执行文件。

打开 `database/create-user.example.sql`，替换占位密码，再执行：

```bash
mysql --protocol=TCP -h127.0.0.1 -P3306 -uroot -p < database/create-user.example.sql
```

### 第二步：配置并启动后端

复制 `backend/.env.example` 为 `backend/.env.local`。将 `DB_PASSWORD` 改为上一步数据库应用账号的密码，将 `ADMIN_PASSWORD` 设置为自选的至少 12 位密码；两种密码用途不同。管理员账号默认 `curator`，没有随包固定登录密码。

macOS/Linux：

```bash
cd backend
set -a
source .env.local
set +a
mvn verify
java -jar target/zhanxu-backend-1.0.0.jar
```

`mvn verify` 会运行真实 MySQL 集成测试，需先导入初始数据。运行配置只通过环境变量读取，Spring Boot 不会自动加载 `.env.local`，因此 `source` 步骤不能省略。若机器有多个 JDK，先设置 `JAVA_HOME` 指向 JDK 21。也可用 `mvn spring-boot:run` 启动。

Windows PowerShell：在 `backend` 目录手动设置环境变量后运行相同 Maven/Java 命令：

```powershell
$env:DB_URL='jdbc:mysql://127.0.0.1:3306/zhanxu_fullstack?serverTimezone=Asia/Shanghai&characterEncoding=UTF-8'
$env:DB_USERNAME='zhanxu_fullstack_app'
$env:DB_PASSWORD='填写数据库应用账号密码'
$env:ADMIN_USERNAME='curator'
$env:ADMIN_PASSWORD='填写自选的至少12位管理密码'
mvn verify
java -jar target/zhanxu-backend-1.0.0.jar
```

浏览器访问 `http://127.0.0.1:8081/api/exhibitions` 应返回包含 3 个公开展览的 JSON。

### 第三步：启动三个前端

另开三个终端，分别执行下表中的命令（路径相对提交包根目录）：

| 端 | 命令 | 地址 |
| --- | --- | --- |
| Web | `cd web`，`npm ci`，`npm run dev` | http://127.0.0.1:5173/ |
| 管理后台 | `cd admin`，`npm ci`，`npm run dev` | http://127.0.0.1:5174/ |
| 移动 H5 | `cd mobile`，`npm ci`，`npm run dev` | http://127.0.0.1:5175/ |

使用 `curator` 和自己配置的 `ADMIN_PASSWORD` 登录管理后台。移动 H5 可在 Chrome 开发者工具设备模式中选择 390×844 视口查看。

如需在真实手机访问，仅将移动前端绑定到局域网：在 `mobile` 中运行 `npm run dev -- --host 0.0.0.0`，手机与电脑连接同一 Wi-Fi，在手机打开 `http://电脑局域网IP:5175/`。后端继续监听电脑本机，由 Vite 代理 API。仅在可信本地网络演示；真实手机访问本次未实测。

### 第四步：构建与停止

各前端目录运行 `npm run build` 生成 `dist/`，之后 `npm run preview` 在原端口预览，需要后端同时运行。不要双击 `index.html`。修改后端端口时，前端可用 `API_TARGET=http://127.0.0.1:新端口 npm run dev` 修改代理。

手动启动时保持四个终端运行，在对应终端按 Ctrl+C 停止；数据库记录仍保留。需要脱离终端运行时，可在服务端使用系统服务管理器或 `nohup`。本次本机验证采用独立后台进程启动，不依赖聊天会话存活。

## 6. API 接口说明

基地址：`http://127.0.0.1:8081`；JSON 编码 UTF-8；日期格式 `yyyy-MM-dd'T'HH:mm:ss`，按上海本地时间解释。`id` 为数据库主键。本次不支持分页，适用于课程演示数据规模。

| 方法 | 路径 | 用途 / 权限 |
| --- | --- | --- |
| GET | `/api/exhibitions?q=&status=` | 公开展览列表；标题包含搜索、状态过滤 |
| GET | `/api/exhibitions/{id}` | 公开展览详情；私有或不存在返回 404 |
| GET | `/api/home` | 原有首页展览与精选作品数据 |
| POST | `/api/admin/login` | 管理员登录，成功设置会话 Cookie |
| GET | `/api/admin/session` | 读取当前会话，未登录返回 401 |
| POST | `/api/admin/logout` | 注销当前会话 |
| GET | `/api/admin/exhibitions?q=&status=` | 管理员查看全部展览，包括私有和草稿 |
| POST | `/api/admin/exhibitions` | 新建展览，返回 201 与完整记录 |
| PUT | `/api/admin/exhibitions/{id}` | 完整更新展览信息，返回更新后记录 |
| DELETE | `/api/admin/exhibitions/{id}` | 删除未公开且无关联的草稿，返回 204 |

`status` 可选 `draft/collecting/preparing/on_view/archived/cancelled`；公开端仅能返回其中的 `collecting/on_view/archived`。`q` 最多 160 字，使用参数化 SQL 做字面包含搜索。

所有管理写入请求，包括登录和退出，必须带 `X-Zhanxu-Request: 1`。登录以外的管理接口还需有效 Cookie。前端已自动处理，不能只靠隐藏按钮获取权限。

登录请求：

```json
{"username":"curator","password":"你配置的管理密码"}
```

新建/更新请求体（更新时也需提供全部字段）：

```json
{
  "title": "厦园有光",
  "introduction": "山海之间的青年创作展",
  "statement": "在红瓦与海风之间，收集厦园细微的日常。",
  "venue": "校园线上展厅",
  "cover": "/assets/厦园晨雾.png",
  "status": "on_view",
  "visible": true,
  "startsAt": "2026-11-01T09:00:00",
  "endsAt": "2026-11-30T18:00:00"
}
```

返回对象具有上述字段并增加 `id`，列表返回对象数组。`title` 最长 160 字、`introduction` 最长 1000 字、`venue` 最长 255 字、`statement` 最长 5000 字；前三项不允许全空白。封面可用 `厦园晨雾.png`、`凤凰花季.png`、`瓦影.png`、`向海.png`，统一位于 `/assets/` 下。

错误体统一包含 `message`，例如 `{"message":"结束时间必须晚于开始时间"}`。400 表示参数无效；401 表示登录无效/过期；403 表示缺少安全请求头；404 表示记录不存在或未公开；409 表示删除条件不满足或存在数据关联；503 表示数据库暂时不可用。

`/api/home` 是保留的首页接口，返回 `{exhibitions: [...], works: [...]}`；首页推荐最多 3 个展览、4 件作品。完整展览列表与新增展览展示使用 `/api/exhibitions`，不受首页推荐数量限制。

## 7. 验收步骤与证据

1. 在后台创建展览，填入简介、展期、地点，选择封面；以草稿保存。刷新后台后记录仍在，观众端查不到。
2. 编辑这条记录，选择“展出中”并勾选“向观众公开”。保存后刷新 Web 与移动端，可找到同一标题和详情。
3. 后台修改标题或序言并保存，刷新两端详情，检查内容同步；用名称搜索和状态筛选验证列表。
4. 下架该记录，再刷新两端，列表不再出现，直接访问详情返回“展览不存在或尚未公开”。记录仍在后台。
5. 把该测试记录改成未公开草稿，确认后删除。公开中的记录不允许直接删除。

后端自动检查：`backend` 中加载环境变量后运行 `mvn verify`。浏览器检查：先启动四个服务，在 `tests` 中运行 `npm ci`、`npx playwright install chromium`、`npm test`。脚本读取 `backend/.env.local`，创建并删除自己的临时记录，验证登录、UI 写入、三端一致性、刷新持久化、搜索/筛选、模拟 503 错误重试，并重新生成截图。若测试中断，控制台会报告未清理的测试展览 ID，按后台常规操作清理即可。

浏览器截图来自真实运行页面；移动截图使用 390×844 视口模拟，不是手机硬件截图。测试结果见 `tests/验收记录.md` 和 `tests/browser-result.json`。不要在已有其他人工演示数据的数据库上直接要求初始数据数量测试通过，建议使用本提交包的初始数据库进行验收。

## 8. 范围与已知限制

本次交付完成“展览管理与浏览”模块。作品投稿、审核编排、预约核验、观众登录、学校身份认证、上传文件和原生 App 不在实现范围内。保留的精选作品只读，管理账号为单一配置账号，新建展览的创建人关联演示策展人 `users.id=1`。

未验证 Windows、Safari、真实手机及公网部署。当前配置用于本机课程演示；若部署到公网，需要 HTTPS/Secure Cookie、登录限流、独立用户与角色权限，以及正式反向代理。多人同时编辑同一记录时按最后保存覆盖，本次未实现版本冲突检测。
